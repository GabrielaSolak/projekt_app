﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;

namespace projekt_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            dodajUzytkownika dodajUzytkownika = new();
            dodajUzytkownika.ShowDialog();

            if(dodajUzytkownika.czyDaneOk)
                {
                    Osoba uczen = new();
                    uczen.m_strPesel = dodajUzytkownika.pesel.Text;
                    uczen.m_strImie = dodajUzytkownika.imie.Text;
                    uczen.m_strDrugieImie = dodajUzytkownika.drugie_imie.Text;
                    uczen.m_strNazwisko = dodajUzytkownika.nazwisko.Text;
                    uczen.m_strDataUr = dodajUzytkownika.data_ur.Text;
                    uczen.m_strTelefon = dodajUzytkownika.telefon.Text;
                    uczen.m_strAdres = dodajUzytkownika.adres.Text;
                    uczen.m_strMiejscowosc = dodajUzytkownika.miejscowosc.Text;
                    uczen.m_strKodPocztowy = dodajUzytkownika.kod_pocztowy.Text;

                    listaUczniow.Items.Add(uczen);
            }
        }
        class Osoba
        {
            private string? Imie;
            private string? DrugieImie;
            private string? Nazwisko;
            private string? Miejscowosc;
            private string? Telefon;
            private string? DataUr;
            public string? m_strPesel { get; set; }
            public string? m_strImie
            {
                get { return Imie; }
                set
                {
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        string wprowadzone = value.Trim();
                        Imie = char.ToUpper(wprowadzone[0]) + wprowadzone.Substring(1).ToLower();
                    }
                    else
                    {
                        Imie = "";
                    }
                }
            }
            public string? m_strDrugieImie
            {
                get { return DrugieImie; }
                set
                {
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        string wprowadzone = value.Trim();
                        DrugieImie = char.ToUpper(wprowadzone[0]) + wprowadzone.Substring(1).ToLower();
                    }
                    else
                    {
                        DrugieImie = "";
                    }
                }
            }
            public string? m_strNazwisko
            {
                get { return Nazwisko; }
                set
                {
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        string wprowadzone = value.Trim();
                        var czesci = wprowadzone.Split(' ', '-');
                        for (int i = 0; i < czesci.Length; i++)
                        {
                            czesci[i] = czesci[i].Substring(0, 1).ToUpper() + czesci[i].Substring(1).ToLower();
                        }
                        Nazwisko = string.Join("-", czesci);
                    }
                    else
                    {
                        Nazwisko = "";
                    }
                }
            }
            public string? m_strDataUr
            {
                get { return DataUr; }
                set
                {
                    DataUr = value.Replace('.', '-').Trim();
                }
            }
            public string? m_strTelefon
            {
                get { return Telefon; }
                set
                {   
                    if(!string.IsNullOrWhiteSpace(value))
                    {
                        Telefon = value.Replace(" ", "").Trim();

                        if (!Telefon.StartsWith("+48"))
                            Telefon = "+48" + Telefon;
                    }
                }
            }
            public string? m_strAdres { get; set; }
            public string? m_strMiejscowosc
            {
                get { return Miejscowosc; }
                set
                {
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        string wprowadzone = value.Trim();
                        Miejscowosc = char.ToUpper(wprowadzone[0]) + wprowadzone.Substring(1).ToLower();
                    }
                    else
                    {
                        Miejscowosc = "";
                    }
                }
            }
            public string? m_strKodPocztowy { get; set; }
            public Osoba()
            {
                m_strPesel = "";
                m_strImie = "";
                m_strDrugieImie = "";
                m_strNazwisko = "";
                m_strDataUr = "";
                m_strTelefon = "";
                m_strAdres = "";
                m_strMiejscowosc = "";
                m_strKodPocztowy = "";
            }
        }
        private void NewRecord_Click(object sender, RoutedEventArgs e)
        {
            dodajUzytkownika dodajUzytkownika = new();
            dodajUzytkownika.ShowDialog();
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            var wynik = MessageBox.Show(
                "Czy na pewno chcesz zakończyć działanie programu?",
                "Zamknij aplikację",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (wynik == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown(); //zamkniecie aplikacji
            }
        }
        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Nazwa aplikacji: eDziennik – System Zarządzania Uczniami\n" +
                "Autor: Gabriela Solak\n" +
                "Wersja: 1.0.0\n" +
                "Data wydania: Maj 2025\n" +
                "Opis: Program umożliwia zarządzanie danymi uczniów w prosty i intuicyjny sposób. Użytkownik może dodawać, edytować oraz usuwać rekordy uczniów. Weryfikowane są m.in. poprawność numeru PESEL, zgodność daty urodzenia oraz poprawność kodu pocztowego.", 
                "O programie", 
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";
            if (openFileDialog.ShowDialog() == true)
            {
                listaUczniow.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = ";";
                if (selectedFilterIndex == 1)
                {
                    delimiter = ",";
                }
                Encoding encoding = Encoding.UTF8;
                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns != null)
                        {
                            Osoba uczen = new();
                            uczen.m_strPesel = columns.ElementAtOrDefault(0);
                            uczen.m_strImie = columns.ElementAtOrDefault(1);
                            uczen.m_strDrugieImie = columns.ElementAtOrDefault(2);
                            uczen.m_strNazwisko = columns.ElementAtOrDefault(3);
                            uczen.m_strDataUr = columns.ElementAtOrDefault(4);
                            uczen.m_strTelefon = columns.ElementAtOrDefault(5);
                            uczen.m_strAdres = columns.ElementAtOrDefault(6);
                            uczen.m_strMiejscowosc = columns.ElementAtOrDefault(7);
                            uczen.m_strKodPocztowy = columns.ElementAtOrDefault(8);

                            listaUczniow.Items.Add(uczen);
                        }
                    }
                }
            }
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz jako plik CSV";
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = ";";
                if (saveFileDialog.FilterIndex == 1)
                {
                    delimiter = ",";
                }
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Osoba item in listaUczniow.Items)
                    {
                        var row = $"{item.m_strPesel}{delimiter}{item.m_strImie}{delimiter}{item.m_strDrugieImie}" +
                                  $"{delimiter}{item.m_strNazwisko}{delimiter}{item.m_strDataUr}{delimiter}{item.m_strTelefon}" +
                                  $"{delimiter}{item.m_strAdres}{delimiter}{item.m_strMiejscowosc}{delimiter}{item.m_strKodPocztowy}";
                                  writer.WriteLine(row);
                    }
                }
            }
        }
        private void RemoveSel_Click(object sender, RoutedEventArgs e)
        {
            while (listaUczniow.SelectedItems.Count > 0)
            {
                listaUczniow.Items.Remove(listaUczniow.SelectedItems[0]);
            }
        }
    }
}