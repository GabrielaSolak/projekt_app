﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt_app
{
    /// <summary>
    /// Logika interakcji dla klasy dodajUzytkownika.xaml
    /// </summary>
    public partial class dodajUzytkownika : Window
    {
        public bool czyDaneOk { get; private set; } = false;
        public dodajUzytkownika()
        {
            InitializeComponent();
        }
        private void Anuluj_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(pesel.Text) == false ||
                string.IsNullOrWhiteSpace(imie.Text) == false ||
                string.IsNullOrWhiteSpace(nazwisko.Text) == false ||
                string.IsNullOrWhiteSpace(data_ur.Text) == false ||
                string.IsNullOrWhiteSpace(adres.Text) == false ||
                string.IsNullOrWhiteSpace(miejscowosc.Text) == false ||
                string.IsNullOrWhiteSpace(kod_pocztowy.Text) == false)
            {
                var wynik = MessageBox.Show(
                "Masz niezapisane zmiany. Czy na pewno chcesz zamknąć okno?",
                "Potwierdzenie",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

                if (wynik == MessageBoxResult.Yes)
                {
                    Close(); 
                }
            }
            else
            {
                Close();
            }  
        }
        public void Button_Click(object sender, RoutedEventArgs e)
        {
            string _pesel = pesel.Text;
            string _imie = imie.Text;
            string _drugieImie = drugie_imie.Text;
            string _nazwisko = nazwisko.Text;
            string _dataUr = data_ur.Text;
            string _telefonNr = telefon.Text;
            string _adres = adres.Text;
            string _miejscowosc = miejscowosc.Text;
            string _kodPocztowy = kod_pocztowy.Text;

            //pesel
            bool czyPeselOK = false;
            czyPeselOK = _pesel != null && _pesel.Length == 11 && long.TryParse(_pesel, out _);

            //telefon
            bool czyTelefonOK = false;
            string tel = telefon.Text.Replace(" ", "").Trim();
            if (!tel.StartsWith("+48") && tel.Length == 9 && long.TryParse(tel, out _))
            {
                czyTelefonOK = true;
            }
            else if(tel.StartsWith("+48") && tel.Length == 12 && long.TryParse(tel.Substring(1), out _))
            {
                czyTelefonOK = true;
            }
            else if(string.IsNullOrWhiteSpace(tel)) //telefon jest opcjonalny
            {
                czyTelefonOK = true;
            }

            //data
            bool czyDataUrOK = true;
            int rr = 0, mm = 0, dd = 0;
            string[] data = _dataUr.Split('-', '.');
            if (data.Length == 3 &&
                int.TryParse(data[0], out rr) &&
                int.TryParse(data[1], out mm) &&
                int.TryParse(data[2], out dd))
            {
                if (rr < 1800 || rr > 2299 || mm < 1 || mm > 12 || dd < 1 || dd > 31)
                    czyDataUrOK = false;
            }
            else
            {
                czyDataUrOK = false;
            }

            //suma kontrolna
            char[] peselL = _pesel.ToCharArray();
            int suma = 0;
            int[] wagi = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
            for (int i = 0; i < 10; i++)
            {
                suma += wagi[i] * int.Parse(peselL[i].ToString());
            }
            suma = suma % 10;
            suma = 10 - suma;
            suma = suma % 10;
            int cyfraKontrolna = int.Parse(peselL[10].ToString());
            if (suma != cyfraKontrolna)
            {
                czyPeselOK = false;
            }

            //pesel i data urodzenia
            bool zgodnoscDataPesel = false;
            if (czyPeselOK && czyDataUrOK)
            {
                int pesel_rok = int.Parse(_pesel.Substring(0, 2));
                int pesel_mies = int.Parse(_pesel.Substring(2, 2));
                int pesel_dzien = int.Parse(_pesel.Substring(4, 2));
                int stulecie = 1900;

                if (pesel_mies >= 1 && pesel_mies <= 12)
                {
                    stulecie = 1900;
                }
                else if (pesel_mies >= 21 && pesel_mies <= 32)
                {
                    stulecie = 2000;
                    pesel_mies -= 20;
                }
                else if (pesel_mies >= 41 && pesel_mies <= 52)
                {
                    stulecie = 2100;
                    pesel_mies -= 40;
                }
                else if (pesel_mies >= 61 && pesel_mies <= 72)
                {
                    stulecie = 2200;
                    pesel_mies -= 60;
                }
                else if (pesel_mies >= 81 && pesel_mies <= 92)
                {
                    stulecie = 1800;
                    pesel_mies -= 80;
                }

                int pelnyRok = stulecie + pesel_rok;

                if (pelnyRok == rr && pesel_mies == mm && pesel_dzien == dd)
                {
                    zgodnoscDataPesel = true;
                }
            }

            //kod pocztowy
            bool czyKodPocztowyOK = false;
            string kod = _kodPocztowy.Trim();

            if (kod.Contains("-"))
            {
                var czesci = kod.Split('-');
                if (czesci.Length == 2 &&
                    czesci[0].Length == 2 &&
                    czesci[1].Length == 3)
                {
                    czyKodPocztowyOK = true;
                }
            }

            //sprawdzenie
            if (string.IsNullOrWhiteSpace(_pesel) || 
                string.IsNullOrWhiteSpace(_imie) || 
                string.IsNullOrWhiteSpace(_nazwisko) ||
                string.IsNullOrWhiteSpace(_dataUr) ||
                string.IsNullOrWhiteSpace(_adres) ||
                string.IsNullOrWhiteSpace(_miejscowosc) ||
                string.IsNullOrWhiteSpace(_kodPocztowy))
            {
                MessageBox.Show("Brak danych w polach obowiązkowych.");
            }
            else if (!czyPeselOK)
            {
                pesel.Background = Brushes.Red;
                MessageBox.Show("Niepoprawny pesel.");
            }
            else if(!czyTelefonOK)
            {
                telefon.Background = Brushes.Red;
                MessageBox.Show("Niepoprawny numer telefonu.");
            }
            else if (!czyDataUrOK)
            {
                data_ur.Background = Brushes.Red;
                MessageBox.Show("Niepoprawna data (rrrr-mm-dd).");
            }
            else if (!czyKodPocztowyOK)
            {
                kod_pocztowy.Background = Brushes.Red;
                MessageBox.Show("Niepoprawny kod pocztowy (xx-xxx).");
            }
            else if (!zgodnoscDataPesel)
            {
                pesel.Background = Brushes.Red;
                data_ur.Background = Brushes.Red;
                MessageBox.Show("PESEL nie zgadza się z datą urodzenia.");
            }
            else
            {
                czyDaneOk = true;
                Close();
            }

            //jesli sa okej
            if (czyPeselOK)
            {
                pesel.Background = Brushes.White;
            }
            if (czyTelefonOK)
            {
                telefon.Background= Brushes.White;
            }
            if(czyDataUrOK)
            {
                data_ur.Background = Brushes.White;
            }
            if (czyKodPocztowyOK)
            {
                kod_pocztowy.Background = Brushes.White;
            }
        }
    }
}
