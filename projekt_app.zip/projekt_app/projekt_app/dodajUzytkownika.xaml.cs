﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt_app
{
    /// <summary>
    /// Logika interakcji dla klasy dodajUzytkownika.xaml
    /// </summary>
    public partial class dodajUzytkownika : Window
    {
        public bool czyDaneOk { get; private set; } = false;
        public dodajUzytkownika()
        {
            InitializeComponent();
        }
        


        public void Button_Click(object sender, RoutedEventArgs e)
        {
            string _pesel = pesel.Text;
            string _imie = imie.Text;
            string _drugieImie = drugie_imie.Text;
            string _nazwisko = nazwisko.Text;
            string _dataUr = data_ur.Text;
            string _telefonNr = telefon.Text;
            string _adres = adres.Text;
            string _miejscowosc = miejscowosc.Text;
            string _kodPocztowy = kod_pocztowy.Text;


            
            //pesel
            bool czyPeselOK = false;
            czyPeselOK = _pesel != null && _pesel.Length == 11 && long.TryParse(_pesel, out _);

            //telefon
            bool czyTelefonOK = false;
            string tel = telefon.Text.Replace(" ", "").Trim();
            if (!tel.StartsWith("+48") && tel.Length == 9 && long.TryParse(tel, out _))
            {
                czyTelefonOK = true;
            }
            else if(tel.StartsWith("+48") && tel.Length == 12 && long.TryParse(tel.Substring(1), out _))
            {
                czyTelefonOK = true;
            }
            else if(string.IsNullOrWhiteSpace(tel)) //telefon jest opcjonalny
            {
                czyTelefonOK = true;
            }

            //data
            bool czyDataUrOK = true;
            string[] data = _dataUr.Split('-', '.');
            if(data.Length == 3)
            {
                int rr = int.Parse(data[0]);
                int mm = int.Parse(data[1]);
                int dd = int.Parse(data[2]);

                if (rr < 1800 || rr > 2299 || mm < 1 || mm > 12 || dd < 1 || dd > 31)
                {
                    czyDaneOk = false;
                }
            }
            else
            {
                czyDataUrOK = false;
            }
            
            


            if (string.IsNullOrWhiteSpace(_pesel) || 
                string.IsNullOrWhiteSpace(_imie) || 
                string.IsNullOrWhiteSpace(_nazwisko) ||
                string.IsNullOrWhiteSpace(_dataUr) ||
                string.IsNullOrWhiteSpace(_adres) ||
                string.IsNullOrWhiteSpace(_miejscowosc) ||
                string.IsNullOrWhiteSpace(_kodPocztowy))
            {
                MessageBox.Show("Brak danych w polach obowiązkowych!!");
            }
            else if (!czyPeselOK)
            {
                pesel.Background = Brushes.Red;
                MessageBox.Show("Niepoprawny pesel");
            }
            else if(!czyTelefonOK)
            {
                telefon.Background = Brushes.Red;
                MessageBox.Show("Niepoprawny numer telefonu");
            }
            else if (!czyDataUrOK)
            {
                data_ur.Background = Brushes.Red;
                MessageBox.Show("Niepoprawna data");
            }
            else
            {
                czyDaneOk = true;
                Close();
            }

            //jesli sa okej
            if (czyPeselOK)
            {
                pesel.Background = Brushes.White;
            }
            if (czyTelefonOK)
            {
                telefon.Background= Brushes.White;
            }
            if(czyDataUrOK)
            {
                data_ur.Background = Brushes.White;
            }
        }
    }
}
